// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	#if UNITY_4_0
	public class AnimatorActionBase : FsmStateAction
	{
		
		
		public override void OnAnimatorMove()
		{
			
		}
		public override void OnAnimatorIK()
		{
			
		}

			
	}
	#endif
}