// (c) Copyright HutongGames, LLC 2010-2014. All rights reserved.
/*--- __ECO__ __ACTION__ ---*/

using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory(ActionCategory.Physics)]
	[Tooltip("Makes the collision detection system ignore all collisions between collider1 and collider2.")]
	public class PhysicsIgnoreCollision : FsmStateAction
	{
		[RequiredField]
		[Tooltip("The first collider")]
		[CheckForComponent(typeof(Collider))]
		public FsmOwnerDefault collider1;
		
		[RequiredField]
		[Tooltip("The second collider")]
		[CheckForComponent(typeof(Collider))]
		public FsmGameObject collider2;
		
		[Tooltip("Wether to ignore or not the collisions between collider 1 and 2.")]
		public FsmBool ignoreCollision;
		
		public override void Reset()
		{
			collider1 = null;
			collider2 = null;
			ignoreCollision = true;
		}

		public override void OnEnter()
		{
			doIgnoreCollision();
			
			Finish();
		}
		
		public void doIgnoreCollision()
		{
			GameObject go1 = Fsm.GetOwnerDefaultTarget(collider1);
			if (go1==null || go1.GetComponent<Collider>()==null)
			{
				return;
			}

			GameObject go2 = collider2.Value;
			if (go2==null || go2.GetComponent<Collider>()==null)
			{
				return;
			}

			Physics.IgnoreCollision(go1.GetComponent<Collider>(), go2.GetComponent<Collider>(),ignoreCollision.Value);
		}

	}
}

