// (c) Copyright HutongGames, LLC 2010-2013. All rights reserved.

using UnityEngine;

public class PlayMakerActionsUtils
{
	public enum EveryFrameUpdateSelector {OnUpdate,OnLateUpdate,OnFixedUpdate};

}
